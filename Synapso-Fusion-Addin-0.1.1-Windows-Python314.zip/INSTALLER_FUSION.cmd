@echo off
setlocal
set "SOURCE=%~dp0SynapsoFusionBridge"
set "TARGET=%APPDATA%\Autodesk\Autodesk Fusion 360\API\AddIns\SynapsoFusionBridge"

if not exist "%SOURCE%\synapso_fusion_addin.manifest" (
  echo Paquet Synapso incomplet.
  pause
  exit /b 1
)

if exist "%TARGET%" echo Mise a jour de l'installation existante...

mkdir "%TARGET%" >nul 2>&1
xcopy "%SOURCE%\*" "%TARGET%\" /E /I /H /Y >nul
if errorlevel 1 (
  echo Echec de la copie du complement Fusion.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "$dir=Join-Path $env:LOCALAPPDATA 'Synapso'; New-Item -ItemType Directory -Force -Path $dir | Out-Null; $path=Join-Path $dir 'bridge-secret'; if(-not (Test-Path -LiteralPath $path)){ $bytes=New-Object byte[] 32; $rng=[Security.Cryptography.RandomNumberGenerator]::Create(); $rng.GetBytes($bytes); $rng.Dispose(); $hex=([BitConverter]::ToString($bytes)).Replace('-',''); [IO.File]::WriteAllText($path,$hex) }"
if errorlevel 1 (
  echo Echec de la creation du secret local.
  pause
  exit /b 1
)

echo.
echo Synapso Fusion Bridge est installe.
echo Fermez puis relancez Fusion 360. Le complement demarrera automatiquement.
pause
