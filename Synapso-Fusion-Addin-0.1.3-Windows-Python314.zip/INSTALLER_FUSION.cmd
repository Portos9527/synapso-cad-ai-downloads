@echo off
setlocal
set "SOURCE=%~dp0SynapsoFusionBridge"
set "TARGET=%APPDATA%\Autodesk\Autodesk Fusion 360\API\AddIns\SynapsoFusionBridge"
if not exist "%SOURCE%\synapso_fusion_addin.manifest" exit /b 1
mkdir "%TARGET%" >nul 2>&1
xcopy "%SOURCE%\*" "%TARGET%\" /E /I /H /Y >nul
if errorlevel 1 exit /b 1
powershell -NoProfile -ExecutionPolicy Bypass -Command "$dir=Join-Path $env:LOCALAPPDATA 'Synapso'; New-Item -ItemType Directory -Force -Path $dir | Out-Null; $path=Join-Path $dir 'bridge-secret'; if(-not (Test-Path -LiteralPath $path)){ $bytes=New-Object byte[] 32; $rng=[Security.Cryptography.RandomNumberGenerator]::Create(); $rng.GetBytes($bytes); $rng.Dispose(); $hex=([BitConverter]::ToString($bytes)).Replace('-',''); [IO.File]::WriteAllText($path,$hex) }"
if errorlevel 1 exit /b 1
echo Synapso Fusion Bridge 0.1.3 installe. Relancez Fusion 360.
