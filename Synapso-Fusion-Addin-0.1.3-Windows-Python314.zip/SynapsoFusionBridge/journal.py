"""Local durable job receipts prevent replay after a bridge restart."""

import json
import sqlite3
from pathlib import Path


class BridgeJournal:
    def __init__(self, path: Path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as connection:
            connection.execute(
                "CREATE TABLE IF NOT EXISTS receipts (id TEXT PRIMARY KEY, data TEXT NOT NULL)"
            )
            for id, raw in connection.execute("SELECT id,data FROM receipts").fetchall():
                data = json.loads(raw)
                if data["state"] in {"ACKNOWLEDGED", "RUNNING"}:
                    data.update(state="FAILED", error="RecoveryRequired", inspection=None)
                    connection.execute(
                        "UPDATE receipts SET data=? WHERE id=?", (json.dumps(data), id)
                    )

    def connect(self):
        return sqlite3.connect(self.path, timeout=10)

    def get(self, id):
        with self.connect() as connection:
            row = connection.execute("SELECT data FROM receipts WHERE id=?", (id,)).fetchone()
            return json.loads(row[0]) if row else None

    def put(self, id, data):
        with self.connect() as connection:
            connection.execute(
                "INSERT INTO receipts VALUES (?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data",
                (id, json.dumps(data)),
            )
