"""Loopback-only, authenticated job transport. Dispatch is injected by UI-thread host."""

import hashlib
import hmac
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from uuid import UUID

from packages.cad_ir.schema import CADDocument

from .journal import BridgeJournal

VERSION = "0.1.3"
MAX_BODY = 1024 * 1024


class Bridge:
    def __init__(self, secret: str, dispatch, port: int = 17861, journal_path: Path | None = None):
        if len(secret) < 32:
            raise ValueError("Bridge secret must contain at least 32 characters")
        self.secret, self.dispatch = secret, dispatch
        self.jobs: dict[str, dict] = {}
        self.lock = threading.Lock()
        self.journal = BridgeJournal(journal_path) if journal_path else None
        bridge = self

        class Handler(BaseHTTPRequestHandler):
            def setup(self):
                super().setup()
                self.connection.settimeout(10)

            def log_message(self, *args):
                pass  # Never log tokens, paths, document content, or request bodies.

            def respond(self, code, payload):
                data = json.dumps(payload).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(data)

            def authorized(self):
                # Reject browser-originated access even if a malicious page discovers the port.
                if self.headers.get("Origin") or self.headers.get("Host") not in {
                    f"127.0.0.1:{bridge.server.server_port}",
                    f"localhost:{bridge.server.server_port}",
                }:
                    self.respond(403, {"error": "ForbiddenOrigin"})
                    return False
                supplied = self.headers.get("Authorization", "")
                if not hmac.compare_digest(supplied, "Bearer " + bridge.secret):
                    self.respond(401, {"error": "Unauthorized"})
                    return False
                return True

            def do_GET(self):
                if not self.authorized():
                    return
                if self.path == "/health":
                    with bridge.lock:
                        busy = any(
                            j["state"] in {"ACKNOWLEDGED", "RUNNING"} for j in bridge.jobs.values()
                        )
                    self.respond(
                        200,
                        {
                            "state": "FUSION_BUSY" if busy else "FUSION_READY",
                            "version": VERSION,
                            "heartbeat": time.time(),
                        },
                    )
                elif self.path.startswith("/jobs/"):
                    with bridge.lock:
                        result = bridge.lookup(self.path[6:])
                        payload = (
                            {k: v for k, v in result.items() if k != "hash"} if result else None
                        )
                    self.respond(200 if payload else 404, payload or {"error": "NotFound"})
                else:
                    self.respond(404, {"error": "NotFound"})

            def do_POST(self):
                if not self.authorized():
                    return
                if self.path != "/jobs":
                    self.respond(404, {"error": "NotFound"})
                    return
                try:
                    length = int(self.headers.get("Content-Length", "0"))
                    if not 0 < length <= MAX_BODY:
                        self.respond(413, {"error": "PayloadTooLarge"})
                        return
                    payload = json.loads(self.rfile.read(length))
                    if set(payload) != {"job_id", "cad_ir"}:
                        raise ValueError("Unexpected envelope")
                    id = str(UUID(payload["job_id"]))
                    ir = CADDocument.model_validate_json(json.dumps(payload["cad_ir"]))
                    digest = hashlib.sha256(ir.model_dump_json().encode()).hexdigest()
                except (ValueError, TypeError, KeyError):
                    self.respond(422, {"error": "InvalidCADIR"})
                    return
                with bridge.lock:
                    existing = bridge.lookup(id)
                    if existing:
                        self.respond(
                            200 if existing["hash"] == digest else 409,
                            {"job_id": id, "state": existing["state"]}
                            if existing["hash"] == digest
                            else {"error": "JobConflict"},
                        )
                        return
                    if any(j["state"] in {"ACKNOWLEDGED", "RUNNING"} for j in bridge.jobs.values()):
                        self.respond(409, {"error": "FusionBusy"})
                        return
                    if len(bridge.jobs) >= 100:
                        oldest = next(iter(bridge.jobs))
                        del bridge.jobs[oldest]
                    bridge.jobs[id] = {"job_id": id, "state": "ACKNOWLEDGED", "hash": digest}
                    bridge.persist(id)
                try:
                    bridge.dispatch(id, ir)
                except Exception:
                    bridge.complete(id, error="FusionDispatchFailed")
                self.respond(202, {"job_id": id, "state": "ACKNOWLEDGED"})

        self.server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
        self.server.daemon_threads = True

    def lookup(self, id):
        return self.jobs.get(id) or (self.journal.get(id) if self.journal else None)

    def persist(self, id):
        if self.journal:
            self.journal.put(id, self.jobs[id])

    def started(self, id):
        with self.lock:
            self.jobs[id]["state"] = "RUNNING"
            self.persist(id)

    def complete(self, id: str, inspection=None, error: str | None = None):
        with self.lock:
            self.jobs[id].update(
                {
                    "state": "FAILED" if error else "COMPLETED",
                    "inspection": inspection,
                    "error": error,
                }
            )
            self.persist(id)

    def start(self):
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def stop(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=3)
