"""Fusion add-in entrypoint. Install with scripts/install_fusion.py."""

import os
import queue
import sys
from pathlib import Path

VENDOR = Path(__file__).resolve().parent / "vendor"
if VENDOR.is_dir():
    sys.path.insert(0, str(VENDOR))

_bridge = None
_event = None
_handler = None
_queue = queue.Queue(maxsize=1)
EVENT_ID = "SynapsoTech.CADBridge.Execute.v1"


def bridge_secret():
    configured = os.environ.get("SYNAPSO_BRIDGE_SECRET", "")
    if configured:
        return configured
    root = Path(os.environ.get("LOCALAPPDATA", Path.home() / ".synapso"))
    path = root / "Synapso" / "bridge-secret" if os.name == "nt" else root / "bridge-secret"
    return path.read_text().strip() if path.is_file() else ""


def run(context):
    global _bridge, _event, _handler
    import adsk.core

    from fusion.synapso_fusion_addin.adapter import FusionAdapter
    from fusion.synapso_fusion_addin.bridge import Bridge

    app = adsk.core.Application.get()
    secret = bridge_secret()
    if len(secret) < 32:
        app.userInterface.messageBox(
            "Définissez SYNAPSO_BRIDGE_SECRET (32 caractères minimum) avant de lancer Fusion."
        )
        return
    output = Path(
        os.environ.get("SYNAPSO_EXPORT_ROOT", str(Path.home() / "Documents" / "Synapso CAD"))
    )
    adapter = FusionAdapter(output)

    class Handler(adsk.core.CustomEventHandler):
        def notify(self, args):
            id, ir = _queue.get_nowait()
            _bridge.started(id)
            try:
                result = adapter.execute(ir)
                _bridge.complete(id, inspection=result.model_dump(mode="json"))
            except Exception:
                _bridge.complete(id, error="FusionExecutionFailed")

    def dispatch(id, ir):
        _queue.put_nowait((id, ir))
        app.fireCustomEvent(EVENT_ID)

    _handler = Handler()
    _event = app.registerCustomEvent(EVENT_ID)
    _event.add(_handler)
    _bridge = Bridge(secret, dispatch, journal_path=output / ".bridge-receipts.db")
    _bridge.start()


def stop(context):
    global _bridge, _event, _handler
    import adsk.core

    if _bridge:
        _bridge.stop()
        _bridge = None
    if _event and _handler:
        _event.remove(_handler)
        adsk.core.Application.get().unregisterCustomEvent(EVENT_ID)
    _event = _handler = None
