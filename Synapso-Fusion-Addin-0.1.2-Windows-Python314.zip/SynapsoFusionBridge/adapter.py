"""Official Fusion API mapping, executed exclusively on Fusion's UI thread.

No adsk imports at module load: domain tests run without Autodesk installed.
All values are millimetres in IR and centimetres in Fusion's internal geometry.
"""

from pathlib import Path

from packages.cad_ir.engine import UnsupportedOperation
from packages.cad_ir.schema import (
    Arc,
    CADDocument,
    Circle,
    Constraint,
    Dimension,
    EdgeFeature,
    EdgeSelection,
    Export,
    Extrude,
    Hole,
    Inspection,
    Line,
    Pattern,
    Projection,
    Rectangle,
    Revolve,
    Sketch,
)
from packages.contracts.models import ModelInspection, SketchStatus


class FusionAdapter:
    def __init__(self, output_root: Path):
        import adsk.core
        import adsk.fusion

        self.core, self.fusion = adsk.core, adsk.fusion
        self.output_root = output_root.resolve()
        self.objects = {}
        self.sketches = {}
        self.features = 0
        self.holes = 0

    def point(self, x, y, z=0):
        return self.core.Point3D.create(x / 10, y / 10, z / 10)

    def value(self, value):
        expression = value if isinstance(value, str) else f"{value} mm"
        return self.core.ValueInput.createByString(expression)

    def expression(self, value):
        return value if isinstance(value, str) else f"{value} mm"

    def execute(self, document: CADDocument) -> ModelInspection:
        document = CADDocument.model_validate_json(document.model_dump_json())
        supported = (
            Sketch,
            Rectangle,
            Circle,
            Line,
            Arc,
            Constraint,
            Dimension,
            Projection,
            Extrude,
            Hole,
            Revolve,
            Inspection,
            Export,
            EdgeFeature,
            EdgeSelection,
            Pattern,
        )
        for op in document.operations:
            if not isinstance(op, supported):
                raise UnsupportedOperation(f"Fusion mapping not available: {op.type}")
        self.ir = document
        self.objects, self.sketches = {}, {}
        self.features = self.holes = 0
        app = self.core.Application.get()
        created = app.documents.add(self.core.DocumentTypes.FusionDesignDocumentType)
        self.design = self.fusion.Design.cast(app.activeProduct)
        self.design.designType = self.fusion.DesignTypes.ParametricDesignType
        self.root = self.design.rootComponent
        self.root.name = "Synapso CAD Engine"
        for name, value in document.parameters.items():
            self.design.userParameters.add(name, self.value(value), "mm", "Synapso CAD IR")
        try:
            for op in document.operations:
                self.dispatch(op)
            self.design.computeAll()
            return self.inspect()
        except Exception:
            # Only this newly created document is closed. Existing user documents are untouched.
            created.close(False)
            raise

    def anchor(self, sketch, point, x, y):
        dims = sketch.sketchDimensions
        origin = sketch.originPoint
        if self.ir.resolve(x) == 0 and self.ir.resolve(y) == 0:
            if point != origin:
                sketch.geometricConstraints.addCoincident(point, origin)
            return
        for value, orientation in (
            (x, self.fusion.DimensionOrientations.HorizontalDimensionOrientation),
            (y, self.fusion.DimensionOrientations.VerticalDimensionOrientation),
        ):
            if self.ir.resolve(value) == 0:
                method = (
                    sketch.geometricConstraints.addVerticalPoints
                    if orientation
                    == (self.fusion.DimensionOrientations.HorizontalDimensionOrientation)
                    else sketch.geometricConstraints.addHorizontalPoints
                )
                method(origin, point)
                continue
            dimension = dims.addDistanceDimension(origin, point, orientation, self.point(5, 5))
            dimension.parameter.expression = (
                self.expression(value)
                if self.ir.resolve(value) > 0
                else f"-({self.expression(value)})"
            )

    def rectangle(self, op):
        sketch = self.sketches[op.sketch]
        x, y = (self.ir.resolve(v) for v in op.origin)
        w, h = self.ir.resolve(op.width), self.ir.resolve(op.height)
        if op.type == "center_rectangle":
            lines = sketch.sketchCurves.sketchLines.addCenterPointRectangle(
                self.point(x, y), self.point(x + w / 2, y + h / 2)
            )
        else:
            lines = sketch.sketchCurves.sketchLines.addTwoPointRectangle(
                self.point(x, y), self.point(x + w, y + h)
            )
        # Fusion's rectangle helper creates geometric horizontal/vertical/coincidence relations.
        horizontal = next(
            lines.item(i)
            for i in range(lines.count)
            if not lines.item(i).isConstruction
            and abs(
                lines.item(i).startSketchPoint.geometry.y - lines.item(i).endSketchPoint.geometry.y
            )
            < 1e-7
        )
        vertical = next(
            lines.item(i)
            for i in range(lines.count)
            if not lines.item(i).isConstruction
            and abs(
                lines.item(i).startSketchPoint.geometry.x - lines.item(i).endSketchPoint.geometry.x
            )
            < 1e-7
        )
        for line, value, orient in (
            (
                horizontal,
                op.width,
                self.fusion.DimensionOrientations.HorizontalDimensionOrientation,
            ),
            (vertical, op.height, self.fusion.DimensionOrientations.VerticalDimensionOrientation),
        ):
            dim = sketch.sketchDimensions.addDistanceDimension(
                line.startSketchPoint, line.endSketchPoint, orient, self.point(w, h)
            )
            dim.parameter.expression = self.expression(value)
        if op.type == "center_rectangle":
            corners = [lines.item(i).startSketchPoint for i in range(lines.count)]
            first = min(corners, key=lambda p: p.geometry.x + p.geometry.y)
            opposite = max(corners, key=lambda p: p.geometry.x + p.geometry.y)
            diagonal = sketch.sketchCurves.sketchLines.addByTwoPoints(first, opposite)
            diagonal.isConstruction = True
            center = (
                sketch.originPoint
                if x == 0 and y == 0
                else sketch.sketchPoints.add(self.point(x, y))
            )
            if center != sketch.originPoint:
                self.anchor(sketch, center, *op.origin)
            sketch.geometricConstraints.addMidPoint(center, diagonal)
        else:
            self.anchor(sketch, lines.item(0).startSketchPoint, *op.origin)
        self.objects[op.id] = sketch.profiles.item(0)

    def dispatch(self, op):
        if isinstance(op, Sketch):
            plane = {
                "XY": self.root.xYConstructionPlane,
                "XZ": self.root.xZConstructionPlane,
                "YZ": self.root.yZConstructionPlane,
            }[op.plane]
            if self.ir.resolve(op.offset):
                inp = self.root.constructionPlanes.createInput()
                inp.setByOffset(plane, self.value(op.offset))
                plane = self.root.constructionPlanes.add(inp)
            sketch = self.root.sketches.add(plane)
            sketch.name = op.id
            self.objects[op.id] = self.sketches[op.id] = sketch
        elif isinstance(op, Rectangle):
            self.rectangle(op)
        elif isinstance(op, Circle):
            sketch = self.sketches[op.sketch]
            circle = sketch.sketchCurves.sketchCircles.addByCenterRadius(
                self.point(*(self.ir.resolve(v) for v in op.center)),
                self.ir.resolve(op.radius) / 10,
            )
            dim = sketch.sketchDimensions.addRadialDimension(circle, self.point(10, 10))
            dim.parameter.expression = self.expression(op.radius)
            self.anchor(sketch, circle.centerSketchPoint, *op.center)
            self.objects[op.id] = circle
        elif isinstance(op, Line):
            sketch = self.sketches[op.sketch]
            line = sketch.sketchCurves.sketchLines.addByTwoPoints(
                self.point(*(self.ir.resolve(v) for v in op.start)),
                self.point(*(self.ir.resolve(v) for v in op.end)),
            )
            line.isConstruction = op.type == "construction_line"
            self.objects[op.id] = line
        elif isinstance(op, Arc):
            import math

            self.objects[op.id] = self.sketches[
                op.sketch
            ].sketchCurves.sketchArcs.addByCenterStartSweep(
                self.point(*(self.ir.resolve(v) for v in op.center)),
                self.point(*(self.ir.resolve(v) for v in op.start)),
                math.radians(self.ir.resolve(op.sweep_angle)),
            )
        elif isinstance(op, Constraint):
            constraints = self.sketches[op.sketch].geometricConstraints
            entities = [self.objects[e] for e in op.entities]
            methods = {
                "horizontal": "addHorizontal",
                "vertical": "addVertical",
                "parallel": "addParallel",
                "perpendicular": "addPerpendicular",
                "coincident": "addCoincident",
                "concentric": "addConcentric",
                "tangent": "addTangent",
                "equal": "addEqual",
                "symmetry": "addSymmetry",
                "midpoint": "addMidPoint",
            }
            if op.type in {"fix", "unfix"}:
                entities[0].isFixed = op.type == "fix"
            else:
                self.objects[op.id] = getattr(constraints, methods[op.type])(*entities)
        elif isinstance(op, Dimension):
            dims = self.sketches[op.sketch].sketchDimensions
            entities = [self.objects[e] for e in op.entities]
            label = self.point(10, 10)
            if op.type in {"diameter", "radius"}:
                dim = (
                    dims.addDiameterDimension if op.type == "diameter" else dims.addRadialDimension
                )(entities[0], label)
            elif op.type == "angle":
                dim = dims.addAngularDimension(*entities, label)
            else:
                if len(entities) == 1:
                    entities = [entities[0].startSketchPoint, entities[0].endSketchPoint]
                orientations = {
                    "distance": self.fusion.DimensionOrientations.AlignedDimensionOrientation,
                    "horizontal_distance": self.fusion.DimensionOrientations.HorizontalDimensionOrientation,
                    "vertical_distance": self.fusion.DimensionOrientations.VerticalDimensionOrientation,
                }
                dim = dims.addDistanceDimension(*entities, orientations[op.type], label)
            dim.parameter.expression = (
                f"{self.ir.resolve(op.value)} deg"
                if op.type == "angle"
                else self.expression(op.value)
            )
            self.objects[op.id] = dim
        elif isinstance(op, Projection):
            for entity in op.entities:
                self.objects[op.id] = self.sketches[op.sketch].project(self.objects[entity])
        elif isinstance(op, Extrude):
            profile = self.profile(op.profile)
            operation = (
                self.fusion.FeatureOperations.CutFeatureOperation
                if op.type == "cut"
                else self.fusion.FeatureOperations.NewBodyFeatureOperation
            )
            inp = self.root.features.extrudeFeatures.createInput(profile, operation)
            extent = self.fusion.DistanceExtentDefinition.create(self.value(op.distance))
            direction = (
                self.fusion.ExtentDirections.NegativeExtentDirection
                if op.type == "cut"
                else self.fusion.ExtentDirections.PositiveExtentDirection
            )
            inp.setOneSideExtent(extent, direction)
            if op.body:
                inp.participantBodies = [self.objects[op.body]]
            feature = self.root.features.extrudeFeatures.add(inp)
            feature.name = op.id
            self.objects[op.id] = feature.bodies.item(0)
            self.features += 1
        elif isinstance(op, Hole):
            self.add_holes(op)
        elif isinstance(op, EdgeSelection):
            body = self.objects[op.body]
            selected = self.core.ObjectCollection.create()
            for index in op.indices:
                if index >= body.edges.count:
                    raise ValueError("Edge selector exceeds current body topology")
                selected.add(body.edges.item(index))
            self.objects[op.id] = selected
        elif isinstance(op, EdgeFeature):
            edges = self.core.ObjectCollection.create()
            for reference in op.edges:
                selected = self.objects[reference]
                for i in range(selected.count):
                    edge = selected.item(i)
                    if not edge.isValid:
                        raise ValueError("Stale edge selection")
                    edges.add(edge)
            if op.type == "fillet":
                collection = self.root.features.filletFeatures
                inp = collection.createInput()
                inp.edgeSetInputs.addConstantRadiusEdgeSet(edges, self.value(op.size), True)
            else:
                collection = self.root.features.chamferFeatures
                inp = collection.createInput2()
                inp.chamferEdgeSets.addEqualDistanceChamferEdgeSet(edges, self.value(op.size), True)
            feature = collection.add(inp)
            feature.name = op.id
            self.objects[op.id] = feature
            self.features += 1
        elif isinstance(op, Pattern):
            entities = self.core.ObjectCollection.create()
            for reference in op.entities:
                entities.add(self.objects[reference])
            axis = {
                "X": self.root.xConstructionAxis,
                "Y": self.root.yConstructionAxis,
                "Z": self.root.zConstructionAxis,
            }[op.axis]
            if op.type == "mirror":
                collection = self.root.features.mirrorFeatures
                plane = {
                    "XY": self.root.xYConstructionPlane,
                    "XZ": self.root.xZConstructionPlane,
                    "YZ": self.root.yZConstructionPlane,
                }[op.plane]
                inp = collection.createInput(entities, plane)
            elif op.type == "circular_pattern":
                collection = self.root.features.circularPatternFeatures
                inp = collection.createInput(entities, axis)
                inp.quantity = self.core.ValueInput.createByReal(op.count)
                inp.totalAngle = self.core.ValueInput.createByString(
                    f"{self.ir.resolve(op.angle)} deg"
                )
            else:
                collection = self.root.features.rectangularPatternFeatures
                inp = collection.createInput(
                    entities,
                    axis,
                    self.core.ValueInput.createByReal(op.count),
                    self.value(op.spacing),
                    self.fusion.PatternDistanceType.SpacingPatternDistanceType,
                )
            feature = collection.add(inp)
            feature.name = op.id
            self.objects[op.id] = feature
            self.features += 1
        elif isinstance(op, Revolve):
            features = self.root.features.revolveFeatures
            operation = (
                self.fusion.FeatureOperations.JoinFeatureOperation
                if op.body
                else self.fusion.FeatureOperations.NewBodyFeatureOperation
            )
            inp = features.createInput(
                self.profile(op.profile),
                self.objects[op.axis],
                operation,
            )
            if op.body:
                inp.participantBodies = [self.objects[op.body]]
            inp.setAngleExtent(
                False, self.core.ValueInput.createByString(f"{self.ir.resolve(op.angle)} deg")
            )
            feature = features.add(inp)
            feature.name = op.id
            self.objects[op.id] = feature.bodies.item(0)
            self.features += 1
        elif isinstance(op, Export):
            self.export(op)
        elif isinstance(op, Inspection):
            # Model-wide inspection is returned after all operations.
            if op.type == "measure_distance":
                if len(op.entities) != 2:
                    raise ValueError("Distance inspection requires two entities")
                self.objects[op.id] = (
                    self.core.Application.get()
                    .measureManager.measureMinimumDistance(*(self.objects[e] for e in op.entities))
                    .value
                    * 10
                )

    def profile(self, reference):
        value = self.objects[reference]
        if self.fusion.Profile.cast(value):
            return value
        if value.parentSketch.profiles.count != 1:
            raise UnsupportedOperation(
                "Ambiguous sketch profile: separate profiles into distinct sketches"
            )
        return value.parentSketch.profiles.item(0)

    def add_holes(self, op):
        body = self.objects[op.body]
        # V1 holes run along Z and start on the top planar face of a prismatic/turned base.
        faces = [
            body.faces.item(i)
            for i in range(body.faces.count)
            if self.core.Plane.cast(body.faces.item(i).geometry)
            and abs(self.core.Plane.cast(body.faces.item(i).geometry).normal.z) > 0.999
        ]
        if not faces:
            raise UnsupportedOperation("No horizontal planar face for hole")
        face = max(faces, key=lambda f: f.pointOnFace.z)
        sketch = self.root.sketches.add(face)
        sketch.name = f"{op.id}_positions"
        self.sketches[sketch.name] = sketch
        points = self.core.ObjectCollection.create()
        for x, y in op.positions:
            point = sketch.sketchPoints.add(
                sketch.modelToSketchSpace(
                    self.point(self.ir.resolve(x), self.ir.resolve(y), face.pointOnFace.z * 10)
                )
            )
            # Face coordinate transform means dimensions use measured sketch coordinates.
            self.anchor(sketch, point, point.geometry.x * 10, point.geometry.y * 10)
            points.add(point)
        holes = self.root.features.holeFeatures
        inp = holes.createSimpleInput(self.value(op.diameter))
        inp.setPositionBySketchPoints(points)
        inp.setDistanceExtent(self.value(op.depth))
        inp.participantBodies = [body]
        if op.counterbore_diameter is not None:
            inp.setToCounterbore(
                self.value(op.counterbore_diameter), self.value(op.counterbore_depth)
            )
        feature = holes.add(inp)
        feature.name = op.id
        self.objects[op.id] = feature
        self.features += 1
        self.holes += len(op.positions)

    def inspect(self):
        bodies = self.root.bRepBodies
        volume = sum(bodies.item(i).physicalProperties.volume for i in range(bodies.count)) * 1000
        area = sum(bodies.item(i).physicalProperties.area for i in range(bodies.count)) * 100
        box = self.root.boundingBox
        bounds = tuple(
            (getattr(box.maxPoint, axis) - getattr(box.minPoint, axis)) * 10 for axis in "xyz"
        )
        statuses = [
            SketchStatus(
                id=id,
                status="FULLY_CONSTRAINED"
                if sketch.isFullyConstrained
                else "PARTIALLY_CONSTRAINED",
                degrees_of_freedom=None,
                constraints=sketch.geometricConstraints.count,
                dimensions=sketch.sketchDimensions.count,
            )
            for id, sketch in self.sketches.items()
        ]
        return ModelInspection(
            source="fusion",
            body_count=bodies.count,
            feature_count=self.features,
            volume_mm3=volume,
            surface_area_mm2=area,
            bounding_box_mm=bounds,
            hole_count=self.holes,
            sketches=statuses,
        )

    def export(self, op):
        extensions = {
            "save_f3d": ".f3d",
            "export_step": ".step",
            "export_stl": ".stl",
            "export_dxf": ".dxf",
        }
        self.output_root.mkdir(parents=True, exist_ok=True)
        path = (self.output_root / (op.name + extensions[op.type])).resolve()
        if path.parent != self.output_root:
            raise ValueError("Export path escapes output root")
        if op.type == "export_dxf":
            if not op.sketch:
                raise ValueError("DXF export requires a sketch")
            self.sketches[op.sketch].saveAsDXF(str(path))
            return
        manager = self.design.exportManager
        if op.type == "save_f3d":
            options = manager.createFusionArchiveExportOptions(str(path), self.root)
        elif op.type == "export_step":
            options = manager.createSTEPExportOptions(str(path), self.root)
        else:
            options = manager.createSTLExportOptions(self.root, str(path))
        if not manager.execute(options):
            raise RuntimeError("Fusion export failed")
